﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-50RJ3NI\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
